public class MotorDescompuesto extends RuntimeException {
    public MotorDescompuesto() {
        super("Abandono");
    }
}
