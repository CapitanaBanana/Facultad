
package Robotito;
import robocode.JuniorRobot;

public interface Estratega {

    CombatStrategy elegirEstrategia(JuniorRobot robot);

}
