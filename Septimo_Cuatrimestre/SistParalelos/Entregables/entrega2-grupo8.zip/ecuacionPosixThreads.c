#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <string.h>

/* Funciones */
void initvalmat(double *mat, int n, int transpose);

void blkmul(double *ablk, double *bblk, double *resblk, int n, int bs);

void transpolate(int start, int end);

double generate_random_number(double min, double max);

void *thread_work(void *arg);

double read_matrix(int matrix, int i, int j);

void upload_values(int matrix_id, double min, double max, double average);

double dwalltime();

/* Struct de datos mínimos para los hilos */
typedef struct
{
  int thread_id;
} ThreadData;

/* Variables globales */
double *a;
double *b;
double *c;
double *bt;
double *mr;
int n;
int bs = 128;
int num_threads;

sem_t mutex;
pthread_barrier_t barrier;

double maxA = -1;
double maxB = -1;
double minA = 1e9;
double minB = 1e9;

double averageA = 0.0;
double averageB = 0.0;

/***********************************************************************************/

int main(int argc, char *argv[])
{

  double timetick;

  /* Validación de parámetros */
  if ((argc != 3) || ((n = atoi(argv[1])) <= 0) || ((num_threads = atoi(argv[2])) <= 0) || ((n % bs) != 0))
  {
    printf("\nError en los parámetros. Uso: %s N NUM_THREADS (N debe ser múltiplo de 128 <BS fijo>)\n", argv[0]);
    exit(1);
  }
  if(n==512 & num_threads==8)
    bs=64;

  pthread_t threads[num_threads];

  ThreadData thread_data[num_threads];

  /* Reserva de memoria */
  a = (double *)malloc(n * n * sizeof(double));
  b = (double *)malloc(n * n * sizeof(double));
  c = (double *)malloc(n * n * sizeof(double));
  bt = (double *)malloc(n * n * sizeof(double));
  mr = (double *)malloc(n * n * sizeof(double));

  sem_init(&mutex, 0, 1);
  pthread_barrier_init(&barrier, NULL, num_threads);

  /* Inicialización de matrices */
  srand(time(NULL));
  initvalmat(a, n, 0);
  initvalmat(b, n, 1);
  initvalmat(c, n, 0);
  memset(mr, 0, n * n * sizeof(double));

  /* Multiplicación */
  timetick = dwalltime();
  // Crear los hilos
  for (int i = 0; i < num_threads; i++)
  {
    thread_data[i].thread_id = i;
    pthread_create(&threads[i], NULL, thread_work, (void *)&thread_data[i]);
  }

  for (int i = 0; i < num_threads; i++)
  {
    pthread_join(threads[i], NULL);
  }

  double workTime = dwalltime() - timetick;

  /* Resultados */
  printf("MMBLK-SEC;%d;%d;%d;%.6lf;%.6lf\n", n, bs, num_threads, workTime, ((double)2 * n * n * n) / (workTime * 1e9));

  /* Liberacion de memoria */
  sem_destroy(&mutex);
  free(a);
  free(b);
  free(c);
  free(bt);
  free(mr);
  return 0;
}

/*****************************************************************/

/* Inicialización de matriz con valores aleatorios */
void initvalmat(double *mat, int n, int transpose)
{
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      double val = generate_random_number(1, 100);
      if (transpose)
        mat[j * n + i] = val;
      else
        mat[i * n + j] = val;
    }
  }
}

/* Generar número aleatorio */
double generate_random_number(double min, double max)
{
  return (double)rand() / RAND_MAX * (max - min) + min;
}

/* Leer valores de una matriz */
double read_matrix(int matrix, int i, int j)
{
  return (matrix == 0) ? a[i * n + j] : b[i * n + j]; // Cambiar a 0.0 si no es A ni B (security)
}

void transpolate(int start, int end)
{
  for (int i = start; i < end; i += bs)
  {
    for (int j = 0; j < n; j += bs)
    {
      for (int bi = 0; bi < bs; bi++)
      {
        for (int bj = 0; bj < bs; bj++)
        {
          bt[(j + bj) * n + (i + bi)] = b[(i + bi) * n + (j + bj)];
        }
      }
    }
  }
}

/* Parte paralela */
void *thread_work(void *arg)
{
  ThreadData *data = (ThreadData *)arg;
  int id = data->thread_id;
  int rows_per_thread = n / num_threads;
  int start = id * rows_per_thread;
  int end = (id + 1) * rows_per_thread;
  int matrix_id = id % 2;

  transpolate(start, end);

  double min = 1e9;
  double max = -1;
  double average = 0;

  for (int i = start; i < end; i += bs)
  {
    for (int j = 0; j < n; j += bs)
    {

      for (int k = 0; k < n; k += bs)
        blkmul(&a[i * n + k], &b[j * n + k], &mr[i * n + j], n, bs);
    }
  }

  for (int i = start; i < end; i += bs)
  {
    for (int j = 0; j < n; j += bs)
    {

      for (int k = 0; k < n; k += bs)
        blkmul(&c[i * n + k], &bt[j * n + k], &mr[i * n + j], n, bs);
    }
  }

  /* Calcular max, min y promedio segun matrix_id*/
  for (int i = start; i < end; i++)
  {
    for (int j = 0; j < n; j++)
    {

      double value = read_matrix(matrix_id, i, j);
      if (value > max)
        max = value;

      if (value < min)
        min = value;

      average += value;
    }
  }

  sem_wait(&mutex);
  upload_values(matrix_id, min, max, average);
  sem_post(&mutex);

  /* Esperar a que todos los hilos lleguen para hacer la cuenta*/
  pthread_barrier_wait(&barrier);

  averageA /= (n * n);
  averageB /= (n * n);
  double result = ((maxA * maxB) - (minA * minB)) / (averageA * averageB);
  for (int i = start; i < end; i++)
  {
    for (int j = 0; j < n; j++)
    {
      mr[i * n + j] *= result;
    }
  }

  return NULL;
}

/* Multiplicación de bloques */
void blkmul(double *ablk, double *bblk, double *resblk, int n, int bs)
{
  for (int i = 0; i < bs; i++)
  {
    for (int j = 0; j < bs; j++)
    {
      double sum = 0.0;
      for (int k = 0; k < bs; k++)
      {
        sum += ablk[i * bs + k] * bblk[k + j * n];
      }
      resblk[i * n + j] += sum;
    }
  }
}

/* Actualizar variables globales (siempre accedido con mutex)*/
void upload_values(int matrix_id, double min, double max, double average)
{
  if (matrix_id == 0)
  {
    if (min < minA)
      minA = min;

    if (max > maxA)
      maxA = max;

    averageA += average;
  }
  else
  {
    if (min < minB)
      minB = min;

    if (max > maxB)
      maxB = max;

    averageB += average;
  }
}

/* Tiempo en segundos */
#include <sys/time.h>
double dwalltime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}
