#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <string.h>

/* Funciones */
void initvalmat(double *mat, int n, int transpose);

void matmulblks(double *a, double *b, double *c, double *bt, double *mr, int n, int bs, int num_threads);

void blkmul(double *ablk, double *bblk, double *rsltblk, int n, int bs);

void transpolate(double *original, double *transpolated, int n);

double generateRandomNumber(double min, double max);

double dwalltime();
/***********************************************************************************/

int main(int argc, char *argv[])
{
  double *a;

  double *b;
  double *c;
  double *bt;
  double *mr;
  int n;
  int bs = 128;
  double timetick;
  int num_threads;

  /* Validacion de parametros */
  if ((argc != 3) || ((n = atoi(argv[1])) <= 0) || ((num_threads = atoi(argv[2])) <= 0) || ((n % bs) != 0))
  {
    printf("\nError en los parÃ¡metros. Uso:%s N num_threads (N debe ser mÃºltiplo de BS y num_threads mayor a  o igual 2)\n", argv[0]);
    exit(1);
  }
  
  if(n == 512 && num_threads == 8) bs = 64;

  /* Reserva de memoria */
  a = (double *)malloc(n * n * sizeof(double));
  b = (double *)malloc(n * n * sizeof(double));
  c = (double *)malloc(n * n * sizeof(double));
  bt = (double *)malloc(n * n * sizeof(double));
  mr = (double *)malloc(n * n * sizeof(double));

  /* Inicializacion de matrices */
  srand(time(NULL));
  initvalmat(a, n, 0);
  initvalmat(b, n, 1);
  initvalmat(c, n, 0);

  memset(mr, 0, n * n * sizeof(double));

  /* Multiplicacion */
  timetick = dwalltime();
  matmulblks(a, b, c, bt, mr, n, bs, num_threads);
  double workTime = dwalltime() - timetick;

  /* Resultados */
  printf("MMBLK-SEC;%d;%d;%d;%.6lf;%.6lf\n", n, bs, num_threads, workTime, ((double)2 * n * n * n) / (workTime * 1e9));

  free(a);
  free(b);
  free(c);
  free(bt);
  free(mr);
  return 0;
}

/* Inicializacion de matriz con valores aleatorios */
void initvalmat(double *mat, int n, int transpose)
{
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      double val = generateRandomNumber(1, 100);
      if (transpose)
        mat[j * n + i] = val;
      else
        mat[i * n + j] = val;
    }
  }
}

/* Multiplicacion de matrices por bloques */
void matmulblks(double *a, double *b, double *c, double *bt, double *mr, int n, int bs, int num_threads)
{
  double maxA = -1e9;
  double maxB = -1e9;
  double minA = 1e9;
  double minB = 1e9;

  double promedioA = 0.0;
  double promedioB = 0.0;

  double R = 0.0;

#pragma omp parallel num_threads(num_threads)
  {
    transpolate(b, bt, n);
#pragma omp for schedule(static)
    for (int i = 0; i < n; i += bs)
    {
      for (int j = 0; j < n; j += bs)
      {
        for (int k = 0; k < n; k += bs)
          blkmul(&a[i * n + k], &b[j * n + k], &mr[i * n + j], n, bs);
      }
    }
#pragma omp for schedule(static)
    for (int i = 0; i < n; i += bs)
      for (int j = 0; j < n; j += bs)
      {
        for (int k = 0; k < n; k += bs)
          blkmul(&c[i * n + k], &bt[j * n + k], &mr[i * n + j], n, bs);
      }

#pragma omp for reduction(+ : promedioA) reduction(min : minA) reduction(max : maxA) schedule(static)
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++)
      {
        double val = a[i * n + j];
        promedioA += val;

        if (val < minA)
          minA = val;
        if (val > maxA)
          maxA = val;
      }

#pragma omp for reduction(+ : promedioB) reduction(min : minB) reduction(max : maxB) schedule(static)
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++)
      {
        double val = b[i * n + j];
        promedioB += val;

        if (val < minB)
          minB = val;

        if (val > maxB)
          maxB = val;
      }

    promedioA /= (n * n);
    promedioB /= (n * n);

    R = ((maxA * maxB) - (minA * minB)) / (promedioA * promedioB);

#pragma omp for schedule(static)
    for (int i = 0; i < n; i++)
      for (int j = 0; j < n; j++)
        mr[i * n + j] *= R;
  }
}

/*****************************************************************/

/* Multiplicacion de bloques */
void blkmul(double *ablk, double *bblk, double *rsltblk, int n, int bs)
{
  for (int i = 0; i < bs; i++)
  {
    for (int j = 0; j < bs; j++)
    {
      double totalRes = 0.0;
      for (int k = 0; k < bs; k++)
      {
        totalRes += ablk[i * n + k] * bblk[j * n + k];
      }
      rsltblk[i * n + j] += totalRes;
    }
  }
}

/* Transponer matriz dada otra matriz para multiplicar */
void transpolate(double *original, double *transpolated, int n)
{

#pragma omp for schedule(dynamic, 5)
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      transpolated[j * n + i] = original[i * n + j];
}

/* Generar numero aleatorio */
double generateRandomNumber(double min, double max)
{
  return (double)rand() / RAND_MAX * (max - min) + min;
}

/* Tiempo en segundos */
#include <sys/time.h>
double dwalltime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}
