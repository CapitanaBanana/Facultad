#!/bin/bash
#SBATCH -N 1
#SBATCH --exclusive
#SBATCH --partition=Blade
#SBATCH -o directorioSalida/outputSecuencial.txt
#SBATCH -e directorioSalida/errors.txt

# Crear directorio si no existe
mkdir -p directorioSalida

# Ir al directorio donde est� el c�digo fuente (directorio de trabajo $1)
cd "$1" || exit 1

Ns=(512 1024 2048 4096)
REPS=5

gcc -O3 -o "$2" "$3" -lpthread

for N in "${Ns[@]}"; do
    for ((i = 0; i < REPS; i++)); do
      ./"$2" "$N"  >>../directorioSalida/outputSecuencial.txt
    done
done
