#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Funciones */
void initvalmat(double *mat, int n, int transpose);

void matmulblks(double *a, double *b, double *c, double *bt, double *mr, int n, int bs);

void blkmul(double *ablk, double *bblk, double *rsltblk, int n, int bs);

void transpolate(double *original, double *transpolated, int n);

double generateRandomNumber(double min, double max);

double dwalltime();
/***********************************************************************************/

int main(int argc, char *argv[])
{
  double *a;

  double *b;
  double *c;
  double *bt;
  double *mr;
  int n;
  int bs = 128;
  double timetick;

  /* Validación de parámetros */
  if ((argc != 2) || ((n = atoi(argv[1])) <= 0) || ((n % bs) != 0))
  {
    printf("\nError en los parámetros. Uso: ./%s N BS (N debe ser múltiplo de BS)\n", argv[0]);
    exit(1);
  }

  /* Reserva de memoria */
  a = (double *)malloc(n * n * sizeof(double));
  b = (double *)malloc(n * n * sizeof(double));
  c = (double *)malloc(n * n * sizeof(double));
  bt = (double *)malloc(n * n * sizeof(double));
  mr = (double *)malloc(n * n * sizeof(double));

  /* Inicialización de matrices */
  srand(time(NULL));
  initvalmat(a, n, 0);
  initvalmat(b, n, 1);
  initvalmat(c, n, 0);

  /* Multiplicación */
  timetick = dwalltime();
  transpolate(b, bt, n);
  matmulblks(a, b, c, bt, mr, n, bs);
  double workTime = dwalltime() - timetick;

  /* Resultados */
  printf("MMBLK-SEC;%d;%d;%.6lf;%.6lf\n", n, bs, workTime, ((double)2 * n * n * n) / (workTime * 1e9));

  free(a);
  free(b);
  free(c);
  free(bt);
  free(mr);
  return 0;
}

/* Inicialización de matriz con valores aleatorios */
void initvalmat(double *mat, int n, int transpose)
{
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      double val = generateRandomNumber(1, 100);
      if (transpose)
        mat[j * n + i] = val;
      else
        mat[i * n + j] = val;
    }
  }
}

/* Multiplicación de matrices por bloques */
void matmulblks(double *a, double *b, double *c, double *bt, double *mr, int n, int bs)
{

  double maxA = -1;
  double maxB = -1;
  double minA = 1e9;
  double minB = 1e9;

  double promedioA = 0.0;
  double promedioB = 0.0;

  for (int i = 0; i < n; i += bs)
  {
    for (int j = 0; j < n; j += bs)
    {
      for (int k = 0; k < n; k += bs)
        blkmul(&a[i * n + k], &b[j * n + k], &mr[i * n + j], n, bs);
    }
  }

  for (int i = 0; i < n; i += bs)
  {
    for (int j = 0; j < n; j += bs)
    {
      for (int k = 0; k < n; k += bs)
        blkmul(&c[i * n + k], &bt[j * n + k], &mr[i * n + j], n, bs);
    }
  }

  // Busco max y min de A junto con promedio
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {

      if (a[i * n + j] < minA)
        minA = a[i * n + j];

      if (a[i * n + j] > maxA)
        maxA = a[i * n + j];

      promedioA += a[i * n + j];
    }
  }

  // Busco max y min de B junto con promedio
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      if (b[i * n + j] > maxB)
        maxB = b[i * n + j];

      if (b[i * n + j] < minB)
        minB = b[i * n + j];

      promedioB += b[i * n + j];
    }
  }
  promedioA /= (n * n);
  promedioB /= (n * n);

  double R = ((maxA * maxB) - (minA * minB)) / (promedioA * promedioB);

  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
      mr[i * n + j] *= R;
  }
}

/*****************************************************************/

/* Multiplicación de bloques */
void blkmul(double *ablk, double *bblk, double *rsltblk, int n, int bs)
{
  double totalRes = 0;

  for (int i = 0; i < bs; i++)
  {
    for (int j = 0; j < bs; j++)
    {

      for (int k = 0; k < bs; k++)
        totalRes += ablk[i * n + k] * bblk[j * n + k];

      rsltblk[i * n + j] += totalRes;
    }
  }
}

/* Transponer matriz dada otra matriz para multiplicar */
void transpolate(double *original, double *transpolated, int n)
{
  for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++)
      transpolated[j * n + i] = original[i * n + j];
}

/* Generar número aleatorio */
double generateRandomNumber(double min, double max)
{
  return (double)rand() / RAND_MAX * (max - min) + min;
}

/* Tiempo en segundos */
#include <sys/time.h>
double dwalltime()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec / 1e6;
}
