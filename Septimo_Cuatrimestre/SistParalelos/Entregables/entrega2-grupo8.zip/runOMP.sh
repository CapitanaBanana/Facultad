#!/bin/bash
#SBATCH -N 1
#SBATCH --exclusive
#SBATCH --partition=Blade
#SBATCH -o directorioSalida/outputOMP.txt
#SBATCH -e directorioSalida/errors.txt

# Crear directorio si no existe
mkdir -p directorioSalida

# Ir al directorio donde est� el c�digo fuente (directorio de trabajo $1)
cd "$1" || exit 1

# Compilar el c�digo fuente (asumiendo que $2 es el nombre del ejecutable y $3 es el archivo fuente .c)
gcc -O3 -o "$2" "$3" -fopenmp

# Par�metros
Ns=(512 1024 2048 4096)
NT=(2 4 8)
REPS=5

# Ejecutar con distintos par�metros y guardar salida
for N in "${Ns[@]}"; do
    for NUM_THREADS in "${NT[@]}"; do
        for ((i = 0; i < REPS; i++)); do
            ./"$2" "$N" "$NUM_THREADS" >>../directorioSalida/outputOMP.txt
        done
    done
done